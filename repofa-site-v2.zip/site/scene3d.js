/* ==========================================================
   RepoFA — 3D "Repo Constellation" hero (Three.js r128)
   Core hub + orbiting repo orbs, debris field, raycast tools:
   inspect / star (shatter burst) / fork (spawn child orb) / gravity vortex
   ========================================================== */
(function () {
  'use strict';

  var canvas = document.getElementById('gl');
  var fallback = document.getElementById('glFallback');
  var stub = { ready: false, setTool: function () {}, setCam: function () {}, focus: function () {}, setTheme: function () {}, reset: function () {} };

  function fail() {
    if (fallback) fallback.hidden = false;
    if (canvas) canvas.style.display = 'none';
    window.RepoScene = stub;
    document.dispatchEvent(new CustomEvent('scene:fallback'));
  }
  function webglOK() {
    try {
      var c = document.createElement('canvas');
      return !!(window.WebGLRenderingContext && (c.getContext('webgl2') || c.getContext('webgl')));
    } catch (e) { return false; }
  }
  if (!window.THREE || !canvas || !window.REPOFA || !webglOK()) { fail(); return; }

  var DATA = window.REPOFA;
  var sfx = function (name, v) { if (window.RFX) window.RFX.play(name, v); };

  /* ---------------- Renderer / scene / camera ---------------- */
  var renderer;
  try {
    renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true, alpha: true, powerPreference: 'high-performance' });
  } catch (e) { fail(); return; }
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.outputEncoding = THREE.sRGBEncoding;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.0;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.setClearColor(0x000000, 0);

  var THEMES = {
    carbon: { fog: 0x0E0F12, ink: '#F4F1EA', ink2: '#9E9A90', pill: 'rgba(23,25,30,0.78)', line: 0xF4F1EA, lineOp: 0.14, shadow: 0.45, hemi: 0.5, exposure: 1.0, accent: 0xD4A359, hot: 0xE05A47 },
    paper:  { fog: 0xFAF6F0, ink: '#161513', ink2: '#5C574F', pill: 'rgba(239,232,220,0.9)', line: 0x161513, lineOp: 0.16, shadow: 0.18, hemi: 0.85, exposure: 1.12, accent: 0xC85A32, hot: 0xD93829 }
  };
  var theme = THEMES[document.documentElement.getAttribute('data-theme')] || THEMES.carbon;

  var scene = new THREE.Scene();
  scene.fog = new THREE.Fog(theme.fog, 20, 48);

  var camera = new THREE.PerspectiveCamera(38, 1, 0.1, 200);
  camera.position.set(0, 5, 18);

  var world = new THREE.Group();
  scene.add(world);

  /* ---------------- Procedural environment map (studio softboxes) ---------------- */
  (function buildEnv() {
    var pmrem = new THREE.PMREMGenerator(renderer);
    var env = new THREE.Scene();
    var g = new THREE.SphereGeometry(50, 32, 16);
    var cols = [];
    var pos = g.attributes.position;
    var top = new THREE.Color(0x3a332a), mid = new THREE.Color(0x15161a), bot = new THREE.Color(0x0a0a0c), c = new THREE.Color();
    for (var i = 0; i < pos.count; i++) {
      var y = pos.getY(i) / 50;
      if (y > 0) c.copy(mid).lerp(top, y); else c.copy(mid).lerp(bot, -y);
      cols.push(c.r, c.g, c.b);
    }
    g.setAttribute('color', new THREE.Float32BufferAttribute(cols, 3));
    env.add(new THREE.Mesh(g, new THREE.MeshBasicMaterial({ side: THREE.BackSide, vertexColors: true })));
    function box(w, h, x, y, z, col, ry) {
      var m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ color: col, side: THREE.DoubleSide }));
      m.position.set(x, y, z); m.lookAt(0, 0, 0); if (ry) m.rotateZ(ry);
      env.add(m);
    }
    box(30, 12, -16, 22, 14, 0xfff1dd);    // key softbox
    box(10, 26, 26, 6, -14, 0xffb59a);     // warm rim strip
    box(14, 14, -26, -2, -10, 0xc9dccf);   // cool fill
    box(40, 6, 0, 40, 0, 0xffffff);        // top strip
    var rt = pmrem.fromScene(env, 0.035);
    scene.environment = rt.texture;
    pmrem.dispose();
  })();

  /* ---------------- Lights: key / rim / fill / hemi ---------------- */
  var hemi = new THREE.HemisphereLight(0xfff3e0, 0x1b1813, theme.hemi);
  scene.add(hemi);

  var key = new THREE.DirectionalLight(0xfff0da, 1.55);
  key.position.set(-7, 13, 9);
  key.castShadow = true;
  key.shadow.mapSize.set(2048, 2048);
  key.shadow.camera.left = -14; key.shadow.camera.right = 14;
  key.shadow.camera.top = 14; key.shadow.camera.bottom = -14;
  key.shadow.camera.near = 1; key.shadow.camera.far = 45;
  key.shadow.bias = -0.0005;
  key.shadow.normalBias = 0.02;
  key.shadow.radius = 5;
  scene.add(key);

  var rim = new THREE.SpotLight(theme.hot, 2.4, 45, Math.PI / 5, 0.65, 1.2);
  rim.position.set(10, 7, -9);
  rim.target.position.set(0, 0, 0);
  scene.add(rim); scene.add(rim.target);

  var fill = new THREE.PointLight(0xbfd8cb, 0.9, 34, 1.6);
  fill.position.set(-9, -1, 7);
  scene.add(fill);

  var coreLight = new THREE.PointLight(theme.accent, 1.2, 12, 2);
  world.add(coreLight);

  /* ---------------- Ground (shadow catcher + rings) ---------------- */
  var GROUND_Y = -3.4;
  var ground = new THREE.Mesh(
    new THREE.CircleGeometry(30, 64),
    new THREE.ShadowMaterial({ opacity: theme.shadow })
  );
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = GROUND_Y;
  ground.receiveShadow = true;
  world.add(ground);

  var lineMat = new THREE.LineBasicMaterial({ color: theme.line, transparent: true, opacity: theme.lineOp, fog: true });
  var groundRings = new THREE.Group();
  [3, 6, 9, 12].forEach(function (r, i) {
    var pts = [];
    for (var a = 0; a <= 128; a++) { var t = a / 128 * Math.PI * 2; pts.push(new THREE.Vector3(Math.cos(t) * r, 0, Math.sin(t) * r)); }
    var l = new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), lineMat.clone());
    l.material.opacity = theme.lineOp * (1 - i * 0.18);
    groundRings.add(l);
  });
  groundRings.position.y = GROUND_Y + 0.01;
  world.add(groundRings);

  /* ---------------- Materials ---------------- */
  var brass = new THREE.MeshPhysicalMaterial({ color: 0xD4A359, metalness: 1, roughness: 0.28, clearcoat: 0.7, clearcoatRoughness: 0.18, envMapIntensity: 1.1 });
  var graphite = new THREE.MeshPhysicalMaterial({ color: 0x23262d, metalness: 0.6, roughness: 0.42, clearcoat: 0.4, clearcoatRoughness: 0.4 });
  var glass = new THREE.MeshPhysicalMaterial({
    color: 0xfaf3e6, metalness: 0, roughness: 0.06, transmission: 0.9, transparent: true, opacity: 0.42,
    clearcoat: 1, clearcoatRoughness: 0.05, envMapIntensity: 1.4, side: THREE.DoubleSide, depthWrite: false
  });

  /* ---------------- Core hub (composite gyroscope) ---------------- */
  var core = new THREE.Group();
  world.add(core);

  var coreShell = new THREE.Mesh(new THREE.IcosahedronGeometry(1.55, 3), glass);
  coreShell.renderOrder = 2;
  core.add(coreShell);

  var coreHeart = new THREE.Mesh(new THREE.OctahedronGeometry(0.72, 0), new THREE.MeshPhysicalMaterial({
    color: theme.accent, metalness: 0.9, roughness: 0.22, clearcoat: 1, emissive: theme.accent, emissiveIntensity: 0.18, flatShading: true
  }));
  coreHeart.castShadow = true;
  core.add(coreHeart);

  var gyro = [];
  [[2.05, 0.045, 0, 0], [2.35, 0.03, Math.PI / 2.6, 0.4], [2.65, 0.022, -Math.PI / 3.2, -0.6]].forEach(function (r, i) {
    var ring = new THREE.Mesh(new THREE.TorusGeometry(r[0], r[1], 16, 160), i === 0 ? brass : graphite);
    ring.rotation.set(Math.PI / 2 + r[2], r[3], 0);
    ring.castShadow = true;
    core.add(ring);
    gyro.push(ring);
  });

  // small "commit" beads riding on the first gyro ring
  var beadGeo = new THREE.SphereGeometry(0.075, 16, 12);
  for (var b = 0; b < 10; b++) {
    var bead = new THREE.Mesh(beadGeo, brass);
    var ang = b / 10 * Math.PI * 2;
    bead.position.set(Math.cos(ang) * 2.05, Math.sin(ang) * 2.05, 0);
    gyro[0].add(bead);
  }

  /* ---------------- Label sprites ---------------- */
  function makeLabel(text, colorHex) {
    var cv = document.createElement('canvas');
    cv.width = 640; cv.height = 128;
    var tex = new THREE.CanvasTexture(cv);
    tex.encoding = THREE.sRGBEncoding;
    tex.anisotropy = 4;
    var mat = new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false, opacity: 0.0, fog: false });
    var sp = new THREE.Sprite(mat);
    sp.scale.set(2.9, 0.58, 1);
    sp.userData = { cv: cv, tex: tex, text: text, color: colorHex };
    drawLabel(sp);
    return sp;
  }
  function drawLabel(sp) {
    var u = sp.userData, ctx = u.cv.getContext('2d');
    ctx.clearRect(0, 0, 640, 128);
    ctx.font = '600 40px "JetBrains Mono", ui-monospace, monospace';
    var w = Math.min(600, ctx.measureText(u.text).width + 86);
    var x = (640 - w) / 2;
    ctx.fillStyle = theme.pill;
    roundRect(ctx, x, 24, w, 80, 40); ctx.fill();
    ctx.strokeStyle = 'rgba(158,154,144,0.35)'; ctx.lineWidth = 2; ctx.stroke();
    ctx.fillStyle = u.color;
    ctx.beginPath(); ctx.arc(x + 38, 64, 10, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = theme.ink;
    ctx.textBaseline = 'middle';
    ctx.fillText(u.text, x + 60, 66, w - 76);
    u.tex.needsUpdate = true;
  }
  function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
  }

  /* ---------------- Repo orbs ---------------- */
  var orbs = [];
  var pickables = [];
  var tmpV = new THREE.Vector3(), tmpV2 = new THREE.Vector3();
  var reps = DATA.repos;

  function catColor(cat) { return new THREE.Color((DATA.categories[cat] || {}).color || '#D4A359'); }

  reps.forEach(function (r, i) {
    var col = catColor(r.cat);
    var pop = r.totalReactions || 20;
    var size = 0.42 + Math.min(pop, 80) / 80 * 0.34;

    var g = new THREE.Group();
    var body = new THREE.Mesh(new THREE.SphereGeometry(size, 48, 32), new THREE.MeshPhysicalMaterial({
      color: col, metalness: 0.25, roughness: 0.32, clearcoat: 1, clearcoatRoughness: 0.12,
      emissive: col, emissiveIntensity: 0.0
    }));
    body.castShadow = true; body.receiveShadow = true;
    g.add(body);

    // engraved band
    var band = new THREE.Mesh(new THREE.TorusGeometry(size * 1.42, 0.018, 8, 96), graphite);
    band.rotation.x = Math.PI / 2 + (i % 2 ? 0.35 : -0.35);
    band.castShadow = true;
    g.add(band);

    // tiny satellite (the "star" indicator)
    var sat = new THREE.Mesh(new THREE.IcosahedronGeometry(size * 0.18, 0), brass);
    sat.castShadow = true;
    g.add(sat);

    // glass halo for hover
    var halo = new THREE.Mesh(new THREE.SphereGeometry(size * 1.22, 32, 24), new THREE.MeshPhysicalMaterial({
      color: col, roughness: 0.1, transmission: 0.6, transparent: true, opacity: 0, depthWrite: false
    }));
    g.add(halo);

    var label = makeLabel(r.name, '#' + col.getHexString());
    label.position.y = size + 0.62;
    g.add(label);

    var radius = 4.3 + (i % 3) * 1.55 + (i * 0.17);
    var orb = {
      repo: r, idx: i, group: g, body: body, band: band, sat: sat, halo: halo, label: label, size: size, color: col,
      radius: radius,
      angle: (i / reps.length) * Math.PI * 2,
      speed: 0.11 + (reps.length - i) * 0.008 * (i % 2 ? 1 : -0.6),
      tilt: (i % 2 ? 1 : -1) * (0.12 + (i % 3) * 0.06),
      yBase: -0.2 + ((i * 37) % 5) * 0.32,
      offset: new THREE.Vector3(), vel: new THREE.Vector3(),
      hover: 0, stars: 0, forks: [], pulse: 0, squash: 0
    };
    body.userData.orb = orb; halo.userData.orb = orb;
    pickables.push(body);
    world.add(g);
    orbs.push(orb);
  });

  // tether lines core -> orb
  var tetherGeo = new THREE.BufferGeometry();
  var tetherPos = new Float32Array(orbs.length * 6);
  tetherGeo.setAttribute('position', new THREE.BufferAttribute(tetherPos, 3));
  var tetherMat = new THREE.LineBasicMaterial({ color: theme.line, transparent: true, opacity: theme.lineOp * 0.8 });
  var tethers = new THREE.LineSegments(tetherGeo, tetherMat);
  world.add(tethers);

  function orbitPos(o, out) {
    var x = Math.cos(o.angle) * o.radius;
    var z = Math.sin(o.angle) * o.radius;
    var y = o.yBase + Math.sin(o.angle * 2 + o.idx) * 0.35 + x * o.tilt * 0.25;
    return out.set(x, y, z);
  }

  /* ---------------- Debris / particle field (instanced) ---------------- */
  var DEBRIS = window.innerWidth < 700 ? 260 : 520;
  var debrisGeo = new THREE.TetrahedronGeometry(0.06, 0);
  var debrisMat = new THREE.MeshPhysicalMaterial({ color: 0xcfc6b5, metalness: 0.5, roughness: 0.4, clearcoat: 0.5 });
  var debris = new THREE.InstancedMesh(debrisGeo, debrisMat, DEBRIS);
  debris.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  var dState = [];
  var dummy = new THREE.Object3D();
  var dCols = [new THREE.Color(0xcfc6b5), new THREE.Color(0xD4A359), new THREE.Color(0xE05A47), new THREE.Color(0x6FA287), new THREE.Color(0x8a857c)];
  for (var d = 0; d < DEBRIS; d++) {
    var rr = 3 + Math.pow(Math.random(), 0.7) * 13;
    var aa = Math.random() * Math.PI * 2;
    var p = new THREE.Vector3(Math.cos(aa) * rr, (Math.random() - 0.5) * 7, Math.sin(aa) * rr);
    dState.push({
      p: p, v: new THREE.Vector3(), home: p.clone(),
      rot: new THREE.Euler(Math.random() * 6, Math.random() * 6, 0),
      spin: (Math.random() - 0.5) * 2, s: 0.5 + Math.random() * 1.6,
      orbit: (0.02 + Math.random() * 0.05) * (Math.random() < 0.5 ? 1 : -1)
    });
    debris.setColorAt(d, dCols[(Math.random() * dCols.length) | 0]);
  }
  debris.instanceColor.needsUpdate = true;
  debris.frustumCulled = false;
  world.add(debris);

  /* ---------------- Shatter fragments (pooled instanced) ---------------- */
  var FRAG_MAX = 420;
  var fragGeo = new THREE.TetrahedronGeometry(0.11, 0);
  var fragMat = new THREE.MeshPhysicalMaterial({ metalness: 0.4, roughness: 0.3, clearcoat: 1 });
  var frags = new THREE.InstancedMesh(fragGeo, fragMat, FRAG_MAX);
  frags.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  frags.castShadow = true;
  var fState = [];
  for (var f = 0; f < FRAG_MAX; f++) {
    fState.push({ alive: false, p: new THREE.Vector3(), v: new THREE.Vector3(), r: new THREE.Euler(), w: new THREE.Vector3(), life: 0, s: 1 });
    frags.setColorAt(f, new THREE.Color(0xffffff));
    dummy.position.set(0, -999, 0); dummy.scale.setScalar(0.0001); dummy.updateMatrix();
    frags.setMatrixAt(f, dummy.matrix);
  }
  frags.instanceColor.needsUpdate = true;
  frags.frustumCulled = false;
  world.add(frags);
  var fragCursor = 0;
  var liveFrags = 0;

  function burst(origin, color, n, power) {
    var c = new THREE.Color(color);
    var accentC = new THREE.Color(theme.accent);
    for (var k = 0; k < n; k++) {
      var slot = fragCursor;
      var s = fState[slot];
      fragCursor = (fragCursor + 1) % FRAG_MAX;
      s.alive = true;
      s.p.copy(origin);
      var th = Math.random() * Math.PI * 2, ph = Math.acos(2 * Math.random() - 1);
      var sp = (0.5 + Math.random()) * power;
      s.v.set(Math.sin(ph) * Math.cos(th) * sp, Math.abs(Math.cos(ph)) * sp * 0.9 + 1.5, Math.sin(ph) * Math.sin(th) * sp);
      s.r.set(Math.random() * 6, Math.random() * 6, Math.random() * 6);
      s.w.set((Math.random() - 0.5) * 12, (Math.random() - 0.5) * 12, (Math.random() - 0.5) * 12);
      s.life = 2.4 + Math.random() * 1.4;
      s.s = 0.5 + Math.random() * 1.1;
      frags.setColorAt(slot, Math.random() < 0.25 ? accentC : c);
    }
    frags.instanceColor.needsUpdate = true;
  }

  /* ---------------- Shockwave rings ---------------- */
  var waves = [];
  var waveGeo = new THREE.RingGeometry(0.9, 1, 96);
  function shockwave(pos, color, flat) {
    var m = new THREE.Mesh(waveGeo, new THREE.MeshBasicMaterial({ color: color, transparent: true, opacity: 0.85, side: THREE.DoubleSide, depthWrite: false }));
    m.position.copy(pos);
    if (flat) { m.rotation.x = -Math.PI / 2; } else { m.lookAt(camera.position); }
    world.add(m);
    waves.push({ m: m, t: 0, dur: 0.9 });
  }

  /* ---------------- Fork children ---------------- */
  var forkGeo = new THREE.SphereGeometry(1, 24, 16);
  var forkCount = 0;
  function addFork(o) {
    if (o.forks.length >= 6) { return false; }
    var m = new THREE.Mesh(forkGeo, new THREE.MeshPhysicalMaterial({ color: o.color, metalness: 0.3, roughness: 0.25, clearcoat: 1 }));
    var sz = o.size * (0.26 + Math.random() * 0.1);
    m.scale.setScalar(0.001);
    m.castShadow = true;
    var lg = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]);
    var ln = new THREE.Line(lg, new THREE.LineBasicMaterial({ color: o.color, transparent: true, opacity: 0.55 }));
    o.group.add(m); o.group.add(ln);
    o.forks.push({ m: m, line: ln, size: sz, a: Math.random() * 6.28, r: o.size * (1.9 + o.forks.length * 0.35), sp: 1.2 + Math.random(), tilt: (Math.random() - 0.5) * 1.4, grow: 0 });
    forkCount++;
    return true;
  }

  /* ---------------- Camera controller (damped spherical) ---------------- */
  var cam = {
    theta: 0.35, phi: 1.18, dist: 18, target: new THREE.Vector3(0, 0, 0),
    tTheta: 0.35, tPhi: 1.18, tDist: 18, tTarget: new THREE.Vector3(0, 0, 0),
    auto: 0.06, focusOrb: null, mode: 'orbit'
  };
  var timeScale = 1, tTimeScale = 1;
  var PRESETS = {
    orbit: { phi: 1.18, dist: 18, auto: 0.06, ts: 1 },
    close: { phi: 1.32, dist: 9.5, auto: 0.03, ts: 1 },
    top:   { phi: 0.16, dist: 22, auto: 0.04, ts: 1 },
    slow:  { phi: 1.05, dist: 15, auto: 0.015, ts: 0.22 }
  };
  function setCam(mode) {
    var p = PRESETS[mode]; if (!p) return;
    cam.mode = mode; cam.focusOrb = null;
    cam.tPhi = p.phi; cam.tDist = p.dist * respScale(); cam.auto = p.auto; tTimeScale = p.ts;
    cam.tTarget.set(0, 0, 0);
    sfx('whoosh');
  }
  function respScale() { var a = window.innerWidth / Math.max(1, window.innerHeight); return a < 0.8 ? 1.55 : a < 1.2 ? 1.2 : 1; }
  cam.tDist = cam.dist = 18 * respScale();

  // Offset the composition so the scene sits on the opposite side of the copy (RTL: copy right, scene left)
  var viewShift = new THREE.Vector3();

  /* ---------------- Interaction ---------------- */
  var raycaster = new THREE.Raycaster();
  var ndc = new THREE.Vector2(-9, -9);
  var tool = 'inspect';
  var hovered = null;
  var pointer = { down: false, x: 0, y: 0, sx: 0, sy: 0, moved: 0, id: null, inside: false };
  var gravity = { on: false, point: new THREE.Vector3(), strength: 0 };
  var gravPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
  var shake = 0;
  var counters = { stars: 0, forks: 0 };

  function setNDC(e) {
    var r = canvas.getBoundingClientRect();
    ndc.x = ((e.clientX - r.left) / r.width) * 2 - 1;
    ndc.y = -((e.clientY - r.top) / r.height) * 2 + 1;
  }
  function pick() {
    raycaster.setFromCamera(ndc, camera);
    var hits = raycaster.intersectObjects(pickables, false);
    return hits.length ? hits[0] : null;
  }
  function gravityPoint() {
    raycaster.setFromCamera(ndc, camera);
    gravPlane.normal.set(0, 1, 0);
    gravPlane.constant = 0;
    var hit = new THREE.Vector3();
    if (raycaster.ray.intersectPlane(gravPlane, hit)) { world.worldToLocal(hit); gravity.point.copy(hit); }
  }

  canvas.addEventListener('pointerdown', function (e) {
    pointer.down = true; pointer.id = e.pointerId;
    pointer.x = pointer.sx = e.clientX; pointer.y = pointer.sy = e.clientY; pointer.moved = 0;
    setNDC(e);
    if (tool === 'gravity') {
      gravity.on = true; gravityPoint(); sfx('hum');
    }
    try { canvas.setPointerCapture(e.pointerId); } catch (err) {}
  });
  canvas.addEventListener('pointermove', function (e) {
    pointer.inside = true;
    setNDC(e);
    if (pointer.down && e.pointerId === pointer.id) {
      var dx = e.clientX - pointer.x, dy = e.clientY - pointer.y;
      pointer.moved += Math.abs(dx) + Math.abs(dy);
      pointer.x = e.clientX; pointer.y = e.clientY;
      if (tool === 'gravity') { gravityPoint(); }
      else if (pointer.moved > 6 && e.pointerType !== 'touch') {
        canvas.classList.add('is-dragging');
        cam.tTheta -= dx * 0.0065;
        cam.tPhi = clamp(cam.tPhi - dy * 0.005, 0.12, 1.5);
        cam.focusOrb = null;
      } else if (pointer.moved > 6 && e.pointerType === 'touch' && Math.abs(dx) > Math.abs(dy)) {
        cam.tTheta -= dx * 0.008;
        cam.focusOrb = null;
      }
    }
  });
  function endPointer(e) {
    if (!pointer.down) return;
    pointer.down = false;
    canvas.classList.remove('is-dragging');
    if (gravity.on) { gravity.on = false; sfx('release'); releaseGravity(); }
    if (pointer.moved < 7 && tool !== 'gravity') {
      setNDC(e);
      var h = pick();
      if (h) act(h.object.userData.orb, h.point);
      else if (tool === 'inspect') { hideInspector(); }
    }
  }
  canvas.addEventListener('pointerup', endPointer);
  canvas.addEventListener('pointercancel', function () { pointer.down = false; gravity.on = false; canvas.classList.remove('is-dragging'); });
  canvas.addEventListener('pointerleave', function () { pointer.inside = false; ndc.set(-9, -9); });
  canvas.addEventListener('wheel', function (e) {
    // zoom only with Ctrl/⌘ (also trackpad pinch) so normal page scrolling is never hijacked
    if (!(e.ctrlKey || e.metaKey)) return;
    e.preventDefault();
    cam.tDist = clamp(cam.tDist + e.deltaY * 0.012, 7, 30 * respScale());
  }, { passive: false });

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

  function releaseGravity() {
    // fling: everything near the vortex gets an outward kick
    for (var i = 0; i < dState.length; i++) {
      var s = dState[i];
      tmpV.copy(s.p).sub(gravity.point);
      var dd = tmpV.length();
      if (dd < 6) s.v.add(tmpV.normalize().multiplyScalar((6 - dd) * 2.2 * gravity.strength));
    }
    orbs.forEach(function (o) {
      orbitPos(o, tmpV2).add(o.offset);
      tmpV.copy(tmpV2).sub(gravity.point);
      var dd = tmpV.length();
      if (dd < 7) o.vel.add(tmpV.normalize().multiplyScalar((7 - dd) * 1.4 * gravity.strength));
    });
    var wp = gravity.point.clone(); wp.y = GROUND_Y + 0.05;
    shockwave(wp, theme.accent, true);
    shake = Math.max(shake, 0.35 * gravity.strength);
    gravity.strength = 0;
  }

  function act(o, hitPoint) {
    var local = world.worldToLocal(hitPoint.clone());
    if (tool === 'inspect') {
      focus(o.idx);
      sfx('click');
    } else if (tool === 'star') {
      o.stars++; counters.stars++;
      o.pulse = 1; o.squash = 1;
      burst(local, o.color, 46, 5.5);
      shockwave(local, theme.accent, false);
      tmpV.copy(local).sub(orbitPos(o, tmpV2)).normalize().multiplyScalar(-3.2);
      o.vel.add(tmpV);
      // kick nearby debris
      for (var i = 0; i < dState.length; i++) {
        var s = dState[i];
        tmpV.copy(s.p).sub(local); var dd = tmpV.length();
        if (dd < 4) s.v.add(tmpV.normalize().multiplyScalar((4 - dd) * 2.4));
      }
      shake = Math.max(shake, 0.3);
      sfx('star', o.stars);
      emit('star', o);
    } else if (tool === 'fork') {
      if (addFork(o)) {
        counters.forks++;
        o.pulse = 0.8;
        burst(local, o.color, 14, 2.5);
        shockwave(local, o.color.getHex(), false);
        sfx('fork', o.forks.length);
        emit('fork', o);
      } else {
        o.squash = 0.6; sfx('deny');
        emit('forkmax', o);
      }
    }
  }

  function emit(type, o) {
    document.dispatchEvent(new CustomEvent('scene:' + type, { detail: { repo: o ? o.repo : null, stars: counters.stars, forks: counters.forks } }));
  }

  function focus(idx) {
    var o = orbs[idx]; if (!o) return;
    cam.focusOrb = o;
    cam.tDist = 7.5 * Math.min(respScale(), 1.3);
    cam.tPhi = 1.25;
    cam.auto = 0;
    emit('inspect', o);
    showInspector(o);
  }

  /* ---------------- Inspector UI ---------------- */
  var insp = document.getElementById('inspector');
  function showInspector(o) {
    if (!insp) return;
    var cat = DATA.categories[o.repo.cat] || {};
    document.getElementById('inspCat').innerHTML = '<i style="background:' + cat.color + '"></i>' + cat.label;
    document.getElementById('inspName').textContent = o.repo.path;
    document.getElementById('inspTag').textContent = o.repo.tagline;
    var gh = document.getElementById('inspGh'); gh.href = o.repo.url;
    document.getElementById('inspMore').onclick = function () { document.dispatchEvent(new CustomEvent('repo:open', { detail: o.repo.id })); };
    insp.hidden = false;
  }
  function hideInspector() {
    if (insp && !insp.hidden) { insp.hidden = true; cam.focusOrb = null; setCam(cam.mode === 'slow' ? 'slow' : cam.mode); }
  }
  var inspClose = document.getElementById('inspClose');
  if (inspClose) inspClose.addEventListener('click', hideInspector);

  /* ---------------- Resize ---------------- */
  function resize() {
    var w = canvas.clientWidth || window.innerWidth, h = canvas.clientHeight || window.innerHeight;
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    var aspect = w / h;
    // push the scene toward the left on wide screens (copy is on the right in RTL)
    // positive "camera-right" shift moves the constellation to the left half of the screen
    if (aspect > 1.15) viewShift.set(Math.min(6, (aspect - 1) * 5.2), 0, 0);
    else viewShift.set(0, 1.4, 0);
    if (!cam.focusOrb) cam.tDist = (PRESETS[cam.mode] || PRESETS.orbit).dist * respScale();
  }
  window.addEventListener('resize', resize);
  resize();

  /* ---------------- Theme ---------------- */
  function setTheme(name) {
    theme = THEMES[name] || THEMES.carbon;
    scene.fog.color.setHex(theme.fog);
    ground.material.opacity = theme.shadow;
    hemi.intensity = theme.hemi;
    renderer.toneMappingExposure = theme.exposure;
    lineMat.color.setHex(theme.line);
    groundRings.children.forEach(function (l, i) { l.material.color.setHex(theme.line); l.material.opacity = theme.lineOp * (1 - i * 0.18); });
    tetherMat.color.setHex(theme.line); tetherMat.opacity = theme.lineOp * 0.8;
    rim.color.setHex(theme.hot);
    coreLight.color.setHex(theme.accent);
    coreHeart.material.color.setHex(theme.accent); coreHeart.material.emissive.setHex(theme.accent);
    debrisMat.color.setHex(name === 'paper' ? 0x8a8072 : 0xcfc6b5);
    orbs.forEach(function (o) { drawLabel(o.label); });
  }

  /* ---------------- Visibility (pause offscreen) ---------------- */
  var visible = true;
  if ('IntersectionObserver' in window) {
    new IntersectionObserver(function (en) { visible = en[0].isIntersecting; if (visible) clock.getDelta(); }, { threshold: 0 }).observe(canvas);
  }
  document.addEventListener('visibilitychange', function () { if (!document.hidden) clock.getDelta(); });

  /* ---------------- Loop ---------------- */
  var clock = new THREE.Clock();
  var elapsed = 0;
  var fpsAcc = 0, fpsN = 0, fpsT = 0;
  var mFps = document.getElementById('mFps'), mParts = document.getElementById('mParts');
  var mStars = document.getElementById('mStars'), mForks = document.getElementById('mForks');
  var lastHover = null;
  var mouseParallax = new THREE.Vector2();

  function updateHover() {
    if (!pointer.inside || pointer.down) { setHover(null); return; }
    var h = pick();
    setHover(h ? h.object.userData.orb : null);
  }
  function setHover(o) {
    hovered = o;
    if (o !== lastHover) {
      if (o) { canvas.classList.add('is-hover'); sfx('tick'); }
      else canvas.classList.remove('is-hover');
      lastHover = o;
    }
  }

  function step() {
    requestAnimationFrame(step);
    var rawDt = Math.min(clock.getDelta(), 0.05);
    if (!visible || document.hidden) return;

    timeScale += (tTimeScale - timeScale) * Math.min(1, rawDt * 3);
    var dt = rawDt * timeScale;
    elapsed += dt;

    // FPS meter
    fpsAcc += rawDt; fpsN++; fpsT += rawDt;
    if (fpsT > 0.5) { if (mFps) mFps.textContent = Math.round(fpsN / fpsAcc); fpsAcc = 0; fpsN = 0; fpsT = 0; }

    // Gravity strength build-up
    if (gravity.on) gravity.strength = Math.min(1.6, gravity.strength + rawDt * 1.2);

    /* core */
    core.rotation.y += dt * 0.25;
    coreHeart.rotation.x += dt * 0.6; coreHeart.rotation.y += dt * 0.9;
    gyro[0].rotation.z += dt * 0.5;
    gyro[1].rotation.y += dt * 0.35;
    gyro[2].rotation.x += dt * 0.28;
    var corePulse = 1 + Math.sin(elapsed * 2) * 0.02 + (gravity.on ? gravity.strength * 0.08 : 0);
    coreShell.scale.setScalar(corePulse);
    core.position.y = Math.sin(elapsed * 0.8) * 0.12;
    coreLight.intensity = 1.0 + Math.sin(elapsed * 2) * 0.2 + (gravity.on ? gravity.strength : 0);

    /* orbs */
    for (var i = 0; i < orbs.length; i++) {
      var o = orbs[i];
      o.angle += o.speed * dt * (cam.focusOrb === o ? 0.15 : 1);
      orbitPos(o, tmpV2);

      // gravity pull
      if (gravity.on) {
        tmpV.copy(gravity.point).sub(tmpV2).sub(o.offset);
        var dd = Math.max(1.2, tmpV.length());
        o.vel.add(tmpV.normalize().multiplyScalar(gravity.strength * 9 / dd * rawDt));
      }
      // spring back to orbit
      o.vel.addScaledVector(o.offset, -4.2 * rawDt);
      o.vel.multiplyScalar(Math.pow(0.12, rawDt));
      o.offset.addScaledVector(o.vel, rawDt);

      o.group.position.copy(tmpV2).add(o.offset);
      if (o.group.position.y < GROUND_Y + o.size) { o.group.position.y = GROUND_Y + o.size; o.vel.y = Math.abs(o.vel.y) * 0.5; }

      // hover easing
      var hv = hovered === o || cam.focusOrb === o ? 1 : 0;
      o.hover += (hv - o.hover) * Math.min(1, rawDt * 8);
      o.halo.material.opacity = o.hover * 0.22;
      o.halo.scale.setScalar(1 + o.hover * 0.08 + Math.sin(elapsed * 4) * 0.01 * o.hover);
      o.label.material.opacity = 0.35 + o.hover * 0.65;
      o.label.position.y = o.size + 0.6 + o.hover * 0.15;

      // pulse & squash
      o.pulse = Math.max(0, o.pulse - rawDt * 1.6);
      o.squash = Math.max(0, o.squash - rawDt * 2.6);
      var sq = Math.sin(o.squash * Math.PI * 3) * o.squash * 0.18;
      o.body.scale.set(1 + sq, 1 - sq, 1 + sq);
      o.body.material.emissiveIntensity = o.pulse * 0.6 + o.hover * 0.12;

      o.body.rotation.y += dt * 0.4;
      o.band.rotation.z += dt * 0.6;
      var sa = elapsed * 1.4 + i;
      o.sat.position.set(Math.cos(sa) * o.size * 1.42, Math.sin(sa * 0.7) * o.size * 0.3, Math.sin(sa) * o.size * 1.42);
      var ss = 1 + Math.min(o.stars, 12) * 0.12;
      o.sat.scale.setScalar(ss);

      // forks
      for (var k = 0; k < o.forks.length; k++) {
        var fk = o.forks[k];
        fk.grow = Math.min(1, fk.grow + rawDt * 2.2);
        var e = 1 - Math.pow(1 - fk.grow, 3);
        fk.a += dt * fk.sp;
        var fx = Math.cos(fk.a) * fk.r, fz = Math.sin(fk.a) * fk.r, fy = Math.sin(fk.a) * fk.tilt * fk.r * 0.5;
        fk.m.position.set(fx * e, fy * e, fz * e);
        fk.m.scale.setScalar(fk.size * e + 0.0001);
        var lp = fk.line.geometry.attributes.position;
        lp.setXYZ(1, fk.m.position.x, fk.m.position.y, fk.m.position.z);
        lp.needsUpdate = true;
      }

      // tethers
      tetherPos[i * 6] = core.position.x; tetherPos[i * 6 + 1] = core.position.y; tetherPos[i * 6 + 2] = core.position.z;
      tetherPos[i * 6 + 3] = o.group.position.x; tetherPos[i * 6 + 4] = o.group.position.y; tetherPos[i * 6 + 5] = o.group.position.z;
    }
    tetherGeo.attributes.position.needsUpdate = true;

    /* debris */
    for (var di = 0; di < dState.length; di++) {
      var s = dState[di];
      // slow orbit of home
      var ca = Math.cos(s.orbit * dt), sa2 = Math.sin(s.orbit * dt);
      var hx = s.home.x * ca - s.home.z * sa2, hz = s.home.x * sa2 + s.home.z * ca;
      s.home.x = hx; s.home.z = hz;
      if (gravity.on) {
        tmpV.copy(gravity.point).sub(s.p);
        var dl = Math.max(0.6, tmpV.length());
        // swirl + pull
        var tx = -tmpV.z, tz = tmpV.x;
        s.v.x += (tmpV.x / dl * 14 + tx / dl * 9) * gravity.strength * rawDt / Math.sqrt(dl);
        s.v.y += (tmpV.y / dl * 14) * gravity.strength * rawDt / Math.sqrt(dl);
        s.v.z += (tmpV.z / dl * 14 + tz / dl * 9) * gravity.strength * rawDt / Math.sqrt(dl);
      }
      s.v.x += (s.home.x - s.p.x) * 0.9 * rawDt;
      s.v.y += (s.home.y - s.p.y) * 0.9 * rawDt;
      s.v.z += (s.home.z - s.p.z) * 0.9 * rawDt;
      s.v.multiplyScalar(Math.pow(0.35, rawDt));
      s.p.addScaledVector(s.v, dt);
      s.rot.x += s.spin * dt; s.rot.y += s.spin * 0.7 * dt;
      dummy.position.copy(s.p);
      dummy.rotation.copy(s.rot);
      var vs = s.v.length();
      dummy.scale.setScalar(s.s * (1 + Math.min(vs * 0.08, 1.2)));
      dummy.updateMatrix();
      debris.setMatrixAt(di, dummy.matrix);
    }
    debris.instanceMatrix.needsUpdate = true;

    /* fragments: gravity + ground bounce */
    liveFrags = 0;
    for (var fi = 0; fi < FRAG_MAX; fi++) {
      var fs = fState[fi];
      if (!fs.alive) continue;
      fs.life -= rawDt;
      if (fs.life <= 0) {
        fs.alive = false;
        dummy.position.set(0, -999, 0); dummy.scale.setScalar(0.0001); dummy.updateMatrix(); frags.setMatrixAt(fi, dummy.matrix);
        continue;
      }
      liveFrags++;
      fs.v.y -= 9.8 * dt;
      fs.v.multiplyScalar(Math.pow(0.6, dt));
      fs.p.addScaledVector(fs.v, dt);
      if (fs.p.y < GROUND_Y + 0.06) {
        fs.p.y = GROUND_Y + 0.06;
        fs.v.y = -fs.v.y * 0.42; fs.v.x *= 0.7; fs.v.z *= 0.7;
        fs.w.multiplyScalar(0.6);
      }
      fs.r.x += fs.w.x * dt; fs.r.y += fs.w.y * dt; fs.r.z += fs.w.z * dt;
      dummy.position.copy(fs.p); dummy.rotation.copy(fs.r);
      dummy.scale.setScalar(fs.s * Math.min(1, fs.life / 0.6));
      dummy.updateMatrix();
      frags.setMatrixAt(fi, dummy.matrix);
    }
    frags.instanceMatrix.needsUpdate = true;

    /* shockwaves */
    for (var wi = waves.length - 1; wi >= 0; wi--) {
      var w = waves[wi];
      w.t += rawDt;
      var k2 = w.t / w.dur;
      var sc = 0.3 + (1 - Math.pow(1 - k2, 3)) * 4.5;
      w.m.scale.setScalar(sc);
      w.m.material.opacity = 0.85 * (1 - k2);
      if (k2 >= 1) { world.remove(w.m); w.m.material.dispose(); waves.splice(wi, 1); }
    }

    /* camera */
    if (cam.auto && !pointer.down) cam.tTheta += cam.auto * rawDt;
    var damp = Math.min(1, rawDt * 3.2);
    cam.theta += (cam.tTheta - cam.theta) * damp;
    cam.phi += (cam.tPhi - cam.phi) * damp;
    cam.dist += (cam.tDist - cam.dist) * damp;

    if (cam.focusOrb) { cam.tTarget.copy(cam.focusOrb.group.position); }
    else { cam.tTarget.set(0, 0, 0).add(viewShift.clone().applyAxisAngle(new THREE.Vector3(0, 1, 0), cam.theta)); }
    cam.target.lerp(cam.tTarget, damp);

    // subtle mouse parallax
    var px = pointer.inside ? ndc.x : 0, py = pointer.inside ? ndc.y : 0;
    mouseParallax.x += (px - mouseParallax.x) * rawDt * 2;
    mouseParallax.y += (py - mouseParallax.y) * rawDt * 2;

    var th = cam.theta + mouseParallax.x * 0.06, ph = clamp(cam.phi - mouseParallax.y * 0.04, 0.1, 1.52);
    camera.position.set(
      cam.target.x + cam.dist * Math.sin(ph) * Math.sin(th),
      cam.target.y + cam.dist * Math.cos(ph),
      cam.target.z + cam.dist * Math.sin(ph) * Math.cos(th)
    );
    if (shake > 0) {
      shake = Math.max(0, shake - rawDt * 1.4);
      camera.position.x += (Math.random() - 0.5) * shake;
      camera.position.y += (Math.random() - 0.5) * shake;
    }
    camera.lookAt(cam.target);

    updateHover();

    if (mParts) mParts.textContent = DEBRIS + liveFrags + forkCount;
    if (mStars) mStars.textContent = counters.stars;
    if (mForks) mForks.textContent = counters.forks;

    renderer.render(scene, camera);
  }
  requestAnimationFrame(step);

  /* ---------------- Public API ---------------- */
  function reset() {
    orbs.forEach(function (o) {
      o.forks.forEach(function (fk) { o.group.remove(fk.m); o.group.remove(fk.line); fk.m.material.dispose(); fk.line.geometry.dispose(); });
      o.forks = []; o.stars = 0; o.offset.set(0, 0, 0); o.vel.set(0, 0, 0);
    });
    counters.stars = 0; counters.forks = 0; forkCount = 0;
    setCam('orbit');
  }

  window.RepoScene = {
    ready: true,
    setTool: function (t) { tool = t; canvas.style.cursor = t === 'gravity' ? 'crosshair' : ''; },
    setCam: setCam,
    focus: focus,
    setTheme: setTheme,
    reset: reset,
    counters: counters
  };
  document.dispatchEvent(new CustomEvent('scene:ready'));
})();
