/* ==========================================================
   RepoFA — UI application layer
   audio · nav · theme · counters · repos · modal · lab · bento
   card generator · poll · leaderboard
   ========================================================== */
(function () {
  'use strict';

  var D = window.REPOFA;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var fa = function (n) { return Number(n).toLocaleString('fa-IR'); };
  var store = {
    get: function (k, d) { try { var v = localStorage.getItem('repofa:' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem('repofa:' + k, JSON.stringify(v)); } catch (e) {} }
  };
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }

  /* ======================================================
     1. Web Audio — synthesized SFX (off by default)
     ====================================================== */
  var RFX = (function () {
    var ctx = null, master = null, on = store.get('sound', false);
    function init() {
      if (ctx) return;
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      ctx = new AC();
      master = ctx.createGain(); master.gain.value = 0.32;
      var comp = ctx.createDynamicsCompressor();
      master.connect(comp); comp.connect(ctx.destination);
    }
    function tone(freq, dur, type, vol, slide, delay) {
      var t = ctx.currentTime + (delay || 0);
      var o = ctx.createOscillator(), g = ctx.createGain();
      o.type = type || 'sine';
      o.frequency.setValueAtTime(freq, t);
      if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, slide), t + dur);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(vol || 0.3, t + 0.012);
      g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      o.connect(g); g.connect(master);
      o.start(t); o.stop(t + dur + 0.05);
    }
    function noise(dur, vol, fc, q, delay) {
      var t = ctx.currentTime + (delay || 0);
      var len = Math.floor(ctx.sampleRate * dur);
      var buf = ctx.createBuffer(1, len, ctx.sampleRate), d = buf.getChannelData(0);
      for (var i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2);
      var src = ctx.createBufferSource(); src.buffer = buf;
      var f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = fc || 1200; f.Q.value = q || 0.8;
      var g = ctx.createGain(); g.gain.value = vol || 0.3;
      src.connect(f); f.connect(g); g.connect(master);
      src.start(t);
    }
    var humNode = null;
    var lib = {
      tick: function () { tone(1800, 0.04, 'triangle', 0.05); },
      click: function () { tone(660, 0.09, 'triangle', 0.18, 990); },
      whoosh: function () { noise(0.45, 0.22, 700, 0.6); },
      star: function (n) {
        var base = 523.25 * Math.pow(2, ((n || 1) % 8) / 12);
        noise(0.25, 0.35, 2400, 0.7);
        tone(90, 0.3, 'sine', 0.5, 40);
        tone(base, 0.35, 'triangle', 0.22, null, 0.02);
        tone(base * 1.5, 0.45, 'sine', 0.16, null, 0.08);
        tone(base * 2, 0.6, 'sine', 0.1, null, 0.14);
      },
      fork: function (n) { tone(330 + (n || 1) * 40, 0.12, 'square', 0.08, 660 + n * 60); tone(880, 0.2, 'sine', 0.12, null, 0.08); },
      deny: function () { tone(180, 0.18, 'sawtooth', 0.12, 120); },
      hum: function () {
        if (humNode) return;
        var o = ctx.createOscillator(), o2 = ctx.createOscillator(), g = ctx.createGain(), f = ctx.createBiquadFilter();
        o.type = 'sawtooth'; o.frequency.value = 55; o2.type = 'sine'; o2.frequency.value = 82;
        o.frequency.linearRampToValueAtTime(110, ctx.currentTime + 1.5);
        f.type = 'lowpass'; f.frequency.value = 300; f.frequency.linearRampToValueAtTime(1400, ctx.currentTime + 1.5);
        g.gain.setValueAtTime(0.0001, ctx.currentTime); g.gain.exponentialRampToValueAtTime(0.16, ctx.currentTime + 0.3);
        o.connect(f); o2.connect(f); f.connect(g); g.connect(master);
        o.start(); o2.start();
        humNode = { o: o, o2: o2, g: g };
      },
      release: function () {
        if (humNode) {
          var t = ctx.currentTime;
          humNode.g.gain.cancelScheduledValues(t);
          humNode.g.gain.setValueAtTime(humNode.g.gain.value, t);
          humNode.g.gain.exponentialRampToValueAtTime(0.0001, t + 0.25);
          humNode.o.stop(t + 0.3); humNode.o2.stop(t + 0.3); humNode = null;
        }
        noise(0.6, 0.4, 400, 0.5); tone(70, 0.5, 'sine', 0.5, 30);
      },
      pop: function () { tone(520, 0.08, 'sine', 0.2, 900); },
      success: function () { [523.25, 659.25, 783.99, 1046.5].forEach(function (f, i) { tone(f, 0.3, 'triangle', 0.14, null, i * 0.07); }); },
      toggle: function () { tone(440, 0.06, 'square', 0.06); }
    };
    return {
      play: function (name, v) {
        if (!on) return;
        init(); if (!ctx) return;
        if (ctx.state === 'suspended') ctx.resume();
        try { lib[name] && lib[name](v); } catch (e) {}
      },
      set: function (v) { on = v; store.set('sound', v); if (v) { init(); if (ctx && ctx.state === 'suspended') ctx.resume(); } },
      get on() { return on; }
    };
  })();
  window.RFX = RFX;

  var soundBtn = $('#soundBtn');
  soundBtn.setAttribute('aria-pressed', String(RFX.on));
  soundBtn.addEventListener('click', function () {
    RFX.set(!RFX.on);
    soundBtn.setAttribute('aria-pressed', String(RFX.on));
    toast(RFX.on ? 'صدا روشن شد 🔊' : 'صدا خاموش شد');
    RFX.play('success');
  });

  /* ======================================================
     2. Toast
     ====================================================== */
  var toastEl = $('#toast'), toastT;
  function toast(msg) {
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    clearTimeout(toastT);
    toastT = setTimeout(function () { toastEl.classList.remove('show'); }, 2200);
  }

  /* ======================================================
     3. Theme
     ====================================================== */
  function applyTheme(name, silent) {
    document.documentElement.setAttribute('data-theme', name);
    $$('[data-theme-set]').forEach(function (b) {
      var on = b.getAttribute('data-theme-set') === name;
      b.classList.toggle('is-on', on); b.setAttribute('aria-pressed', String(on));
    });
    var meta = $('meta[name="theme-color"]'); if (meta) meta.content = name === 'paper' ? '#FAF6F0' : '#0E0F12';
    store.set('theme', name);
    if (window.RepoScene) window.RepoScene.setTheme(name);
    if (!silent) RFX.play('toggle');
    drawCard();
    drawSpark();
  }
  $$('[data-theme-set]').forEach(function (b) {
    b.addEventListener('click', function () { applyTheme(b.getAttribute('data-theme-set')); });
  });

  /* ======================================================
     4. Nav — hide on scroll, active link, drawer
     ====================================================== */
  var nav = $('#nav'), lastY = 0;
  window.addEventListener('scroll', function () {
    var y = window.scrollY;
    nav.classList.toggle('is-hidden', y > lastY && y > 400 && drawer.hidden);
    lastY = y;
  }, { passive: true });

  var drawer = $('#drawer'), burger = $('#burger');
  burger.addEventListener('click', function () {
    drawer.hidden = !drawer.hidden;
    burger.setAttribute('aria-expanded', String(!drawer.hidden));
  });
  $$('#drawer a').forEach(function (a) { a.addEventListener('click', function () { drawer.hidden = true; burger.setAttribute('aria-expanded', 'false'); }); });

  var navLinks = $$('.nav__links a');
  if ('IntersectionObserver' in window) {
    var secObs = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) {
          navLinks.forEach(function (a) { a.classList.toggle('is-active', a.getAttribute('href') === '#' + en.target.id); });
        }
      });
    }, { rootMargin: '-45% 0px -50% 0px' });
    ['repos', 'lab', 'why', 'card'].forEach(function (id) { var el = document.getElementById(id); if (el) secObs.observe(el); });
  }

  /* ======================================================
     5. Count-up + reveal
     ====================================================== */
  function countUp(el) {
    var target = +el.getAttribute('data-count'), t0 = performance.now(), dur = 1600;
    (function tick(now) {
      var k = Math.min(1, (now - t0) / dur), e = 1 - Math.pow(1 - k, 4);
      el.textContent = fa(Math.round(target * e));
      if (k < 1) requestAnimationFrame(tick);
    })(t0);
  }
  var revealTargets = $$('.sec__head, .repo, .card, .lab__panel, .lab__result, .gen__form, .gen__preview, .final__inner');
  revealTargets.forEach(function (el) { el.classList.add('reveal-up'); });
  if ('IntersectionObserver' in window) {
    var rv = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add('in'); rv.unobserve(en.target); }
      });
    }, { threshold: 0.12 });
    revealTargets.forEach(function (el) { rv.observe(el); });
    var cu = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { if (en.isIntersecting) { countUp(en.target); cu.unobserve(en.target); } });
    });
    $$('[data-count]').forEach(function (el) { cu.observe(el); });
  } else {
    revealTargets.forEach(function (el) { el.classList.add('in'); });
    $$('[data-count]').forEach(countUp);
  }
  function observeReveal(el) { el.classList.add('reveal-up'); if (rv) rv.observe(el); else el.classList.add('in'); }

  /* ======================================================
     6. Marquee
     ====================================================== */
  (function () {
    var names = D.repos.map(function (r) { return '<span>' + esc(r.name) + '</span>'; }).join('');
    $('#marquee').innerHTML = names + names + names + names;
  })();

  /* ======================================================
     7. HUD bindings
     ====================================================== */
  var TOOL_HINT = {
    inspect: 'روی یه کره بزن تا معرفیش رو ببینی',
    star: 'روی کره‌ها بزن تا بهشون ستاره بدی ⭐',
    fork: 'روی کره بزن تا ازش فورک بگیری',
    gravity: 'نگه دار تا گرانش جمع بشه، ول کن تا بترکه'
  };
  $$('.tool').forEach(function (b) {
    b.addEventListener('click', function () {
      $$('.tool').forEach(function (x) { x.classList.remove('is-on'); x.setAttribute('aria-checked', 'false'); });
      b.classList.add('is-on'); b.setAttribute('aria-checked', 'true');
      var t = b.getAttribute('data-tool');
      if (window.RepoScene) window.RepoScene.setTool(t);
      var hint = $('#hint'); if (hint) hint.textContent = TOOL_HINT[t];
      RFX.play('toggle');
    });
  });
  $$('.cam').forEach(function (b) {
    b.addEventListener('click', function () {
      $$('.cam').forEach(function (x) { x.classList.remove('is-on'); });
      b.classList.add('is-on');
      if (window.RepoScene) window.RepoScene.setCam(b.getAttribute('data-cam'));
    });
  });
  document.addEventListener('scene:fallback', function () { var h = $('#hud'); if (h) h.style.display = 'none'; var hint = $('#hint'); if (hint) hint.style.display = 'none'; });
  if (window.RepoScene && !window.RepoScene.ready) { var h0 = $('#hud'); if (h0) h0.style.display = 'none'; var hi0 = $('#hint'); if (hi0) hi0.style.display = 'none'; }

  var starMilestones = { 1: 'اولین ستاره! ⭐', 10: '۱۰ ستاره، داری ترند می‌شی', 25: '۲۵ ستاره؛ رسماً استارگیزر حرفه‌ای', 50: '۵۰ ستاره! برو تو گیت‌هاب واقعی هم بزن 😄' };
  document.addEventListener('scene:star', function (e) {
    var m = starMilestones[e.detail.stars]; if (m) toast(m);
  });
  document.addEventListener('scene:fork', function (e) { if (e.detail.forks === 1) toast('فورک گرفتی از ' + e.detail.repo.name); });
  document.addEventListener('scene:forkmax', function () { toast('این ریپو دیگه جای فورک نداره'); });
  document.addEventListener('repo:open', function (e) { openRepo(e.detail); });

  /* ======================================================
     8. Repo archive grid
     ====================================================== */
  var grid = $('#repoGrid'), chipsEl = $('#chips'), qEl = $('#q'), sortSel = $('#sortSel'), emptyEl = $('#empty');
  var state = { cat: 'all', q: '', sort: 'order' };

  Object.keys(D.categories).forEach(function (k) {
    var c = D.categories[k];
    var n = D.repos.filter(function (r) { return r.cat === k; }).length;
    var b = document.createElement('button');
    b.className = 'chip'; b.setAttribute('data-cat', k); b.setAttribute('role', 'tab'); b.setAttribute('aria-selected', 'false');
    b.innerHTML = '<i style="background:' + c.color + '"></i>' + esc(c.label) + ' <b>' + fa(n) + '</b>';
    chipsEl.appendChild(b);
  });
  chipsEl.querySelector('[data-cat="all"]').innerHTML = 'همه <b>' + fa(D.repos.length) + '</b>';

  function reactStr(r) {
    if (!r.reactions) return '<span>تازه</span>';
    var map = { heart: '❤', like: '👍', fire: '🔥', dislike: '👎', other: '✦' }, out = [];
    Object.keys(r.reactions).slice(0, 3).forEach(function (k) { out.push('<span>' + map[k] + ' ' + fa(r.reactions[k]) + '</span>'); });
    return out.join('');
  }

  function renderRepos() {
    grid.innerHTML = '';
    D.repos.forEach(function (r) {
      var c = D.categories[r.cat];
      var el = document.createElement('article');
      el.className = 'repo';
      el.tabIndex = 0;
      el.setAttribute('data-id', r.id);
      el.setAttribute('role', 'button');
      el.setAttribute('aria-label', r.name + ' — ' + r.tagline);
      el.style.setProperty('--c', c.color);
      el.innerHTML =
        '<div class="repo__top"><span class="repo__cat"><i></i>' + esc(c.label) + '</span><span class="repo__idx">#' + String(r.order).padStart(2, '0') + '</span></div>' +
        (r.demo ? '<span class="repo__demo">دموی آنلاین</span>' : '') +
        '<p class="repo__path">' + esc(r.owner) + ' /</p>' +
        '<h3 class="repo__name">' + esc(r.name) + '</h3>' +
        '<p class="repo__tagline">' + esc(r.tagline) + '</p>' +
        '<p class="repo__sum">' + esc(r.summary) + '</p>' +
        '<div class="repo__foot"><div class="tags">' + r.tags.map(function (t) { return '<span class="tag">' + esc(t) + '</span>'; }).join('') + '</div>' +
        '<span class="repo__react num">' + reactStr(r) + '</span></div>';
      el.addEventListener('click', function () { openRepo(r.id); });
      el.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openRepo(r.id); } });
      el.addEventListener('pointermove', function (e) {
        var b = el.getBoundingClientRect();
        el.style.setProperty('--cx', (e.clientX - b.left) + 'px');
        el.style.setProperty('--cy', (e.clientY - b.top) + 'px');
      });
      grid.appendChild(el);
      observeReveal(el);
    });
    applyFilters();
  }

  function applyFilters() {
    var q = state.q.trim().toLowerCase();
    var list = D.repos.slice();
    if (state.sort === 'reactions') list.sort(function (a, b) { return b.totalReactions - a.totalReactions; });
    else if (state.sort === 'name') list.sort(function (a, b) { return a.name.toLowerCase().localeCompare(b.name.toLowerCase()); });
    else list.sort(function (a, b) { return a.order - b.order; });
    var shown = 0;
    list.forEach(function (r) {
      var el = grid.querySelector('[data-id="' + r.id + '"]');
      grid.appendChild(el);
      var hay = (r.name + ' ' + r.owner + ' ' + r.tagline + ' ' + r.summary + ' ' + r.body + ' ' + r.tags.join(' ') + ' ' + D.categories[r.cat].label).toLowerCase();
      var ok = (state.cat === 'all' || r.cat === state.cat) && (!q || hay.indexOf(q) !== -1);
      el.classList.toggle('is-hidden', !ok);
      if (ok) shown++;
    });
    emptyEl.hidden = shown > 0;
  }

  chipsEl.addEventListener('click', function (e) {
    var b = e.target.closest('.chip'); if (!b) return;
    state.cat = b.getAttribute('data-cat');
    $$('.chip', chipsEl).forEach(function (x) { var on = x === b; x.classList.toggle('is-on', on); x.setAttribute('aria-selected', String(on)); });
    RFX.play('pop');
    applyFilters();
  });
  var qT;
  qEl.addEventListener('input', function () { clearTimeout(qT); qT = setTimeout(function () { state.q = qEl.value; applyFilters(); }, 120); });
  sortSel.addEventListener('change', function () { state.sort = sortSel.value; applyFilters(); RFX.play('toggle'); });

  /* ======================================================
     9. Repo modal
     ====================================================== */
  var modal = $('#modal'), modalBody = $('#modalBody');
  function openRepo(id) {
    var r = D.repos.filter(function (x) { return x.id === id; })[0]; if (!r) return;
    var c = D.categories[r.cat];
    var clone = 'git clone https://github.com/' + r.path + '.git';
    modalBody.innerHTML =
      '<p class="inspector__cat"><i style="background:' + c.color + '"></i>' + esc(c.label) + ' · <span class="mono">' + esc(c.en) + '</span></p>' +
      '<h3>' + esc(r.name) + '</h3>' +
      '<p class="repo__path">' + esc(r.path) + '</p>' +
      '<p class="m-tag">' + esc(r.tagline) + '</p>' +
      '<p class="m-body">' + esc(r.body) + '</p>' +
      '<ul class="m-feat">' + r.features.map(function (f) { return '<li>' + esc(f) + '</li>'; }).join('') + '</ul>' +
      '<div class="m-clone"><code>' + esc(clone) + '</code><button type="button" id="copyClone">کپی</button></div>' +
      '<div class="m-actions">' +
        '<a class="btn btn--accent" href="' + r.url + '" target="_blank" rel="noopener">مشاهده در گیت‌هاب</a>' +
        (r.demo ? '<a class="btn btn--ghost" href="' + r.demo + '" target="_blank" rel="noopener">دموی آنلاین</a>' : '') +
        '<button type="button" class="btn btn--ghost" id="show3d">نمایش در صحنه</button>' +
      '</div>';
    $('#copyClone').addEventListener('click', function () { copyText(clone); });
    $('#show3d').addEventListener('click', function () {
      modal.close();
      window.scrollTo({ top: 0, behavior: 'smooth' });
      var idx = D.repos.indexOf(r);
      setTimeout(function () { if (window.RepoScene) window.RepoScene.focus(idx); }, 450);
    });
    if (typeof modal.showModal === 'function') modal.showModal(); else modal.setAttribute('open', '');
    RFX.play('click');
  }
  modal.addEventListener('click', function (e) { if (e.target === modal) modal.close(); });
  function copyText(t) {
    var done = function () { toast('کپی شد ✓'); RFX.play('pop'); };
    if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(t).then(done, fallbackCopy);
    else fallbackCopy();
    function fallbackCopy() {
      var ta = document.createElement('textarea'); ta.value = t; ta.style.position = 'fixed'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); done(); } catch (e) { toast('کپی نشد'); }
      document.body.removeChild(ta);
    }
  }

  /* ======================================================
     10. Lab — interest matcher (cosine similarity)
     ====================================================== */
  var AXES = [
    { key: 'ai', label: 'هوش مصنوعی و ایجنت', color: '#D4A359' },
    { key: 'cloud', label: 'سرورلس و کلادفلر', color: '#E05A47' },
    { key: 'science', label: 'علم و آموزش', color: '#6FA287' },
    { key: 'tools', label: 'بهره‌وری روزمره', color: '#B9B1A2' }
  ];
  var PRESETS = { ai: [95, 45, 10, 35], ops: [40, 95, 5, 45], sci: [20, 5, 95, 40], prod: [25, 25, 15, 95] };
  var PERSONAS = [
    { name: 'ایجنت‌ساز', sub: 'مدل‌ها رو به ابزار وصل می‌کنی و از حافظه‌ی پایدار لذت می‌بری.' },
    { name: 'معمار سرورلس', sub: 'سرور؟ چه سروری؟ هرچی هست روی Workers اجرا میشه.' },
    { name: 'کاشف علمی', sub: 'شبیه‌ساز و مصورسازی برات از هر فریم‌ورکی جذاب‌تره.' },
    { name: 'بهینه‌ساز روزمره', sub: 'دنبال ابزاری که هر روز یه ربع از وقتت رو پس بده.' }
  ];
  var prefs = store.get('prefs', [70, 50, 40, 50]);
  var sliderEls = [];
  var slidersEl = $('#sliders');
  AXES.forEach(function (a, i) {
    var wrap = document.createElement('div');
    wrap.className = 'sl';
    wrap.innerHTML =
      '<div class="sl__head"><label for="sl-' + a.key + '"><i style="background:' + a.color + '"></i>' + a.label + '</label><output id="o-' + a.key + '" class="num">' + fa(prefs[i]) + '</output></div>' +
      '<input type="range" id="sl-' + a.key + '" min="0" max="100" step="1" value="' + prefs[i] + '" style="--c:' + a.color + '">';
    slidersEl.appendChild(wrap);
    var input = wrap.querySelector('input');
    sliderEls.push(input);
    input.addEventListener('input', function () { prefs[i] = +input.value; updateLab(); });
  });
  var lastTickVal = 0;
  $$('[data-preset]').forEach(function (b) {
    b.addEventListener('click', function () {
      var target = PRESETS[b.getAttribute('data-preset')].slice(), from = prefs.slice(), t0 = performance.now();
      $$('[data-preset]').forEach(function (x) { x.classList.toggle('is-on', x === b); });
      RFX.play('whoosh');
      (function anim(now) {
        var k = Math.min(1, (now - t0) / 500), e = 1 - Math.pow(1 - k, 3);
        for (var i = 0; i < 4; i++) { prefs[i] = Math.round(from[i] + (target[i] - from[i]) * e); sliderEls[i].value = prefs[i]; }
        updateLab();
        if (k < 1) requestAnimationFrame(anim);
      })(t0);
    });
  });
  $('#demoOnly').addEventListener('change', function () { updateLab(); RFX.play('toggle'); });
  $('#popBoost').addEventListener('change', function () { updateLab(); RFX.play('toggle'); });

  var rankEl = $('#rank');
  var rankItems = {};
  D.repos.forEach(function (r) {
    var li = document.createElement('li');
    li.innerHTML = '<span class="rank__n num"></span><div class="rank__mid"><div class="rank__name">' + esc(r.path) + '</div><div class="rank__bar"><i style="--c:' + D.categories[r.cat].color + ';background:' + D.categories[r.cat].color + '"></i></div></div><span class="rank__score"></span>';
    li.style.position = 'relative';
    rankEl.appendChild(li);
    rankItems[r.id] = li;
  });

  var maxReact = Math.max.apply(null, D.repos.map(function (r) { return r.totalReactions || 0; }));
  function cosine(a, b) {
    var dot = 0, na = 0, nb = 0;
    for (var i = 0; i < a.length; i++) { dot += a[i] * b[i]; na += a[i] * a[i]; nb += b[i] * b[i]; }
    return na && nb ? dot / Math.sqrt(na * nb) : 0;
  }
  function updateLab() {
    AXES.forEach(function (a, i) {
      $('#o-' + a.key).textContent = fa(prefs[i]);
      sliderEls[i].style.setProperty('--p', prefs[i] + '%');
    });
    store.set('prefs', prefs);
    var demoOnly = $('#demoOnly').checked, pop = $('#popBoost').checked;
    var scored = D.repos.map(function (r) {
      var s = cosine(prefs, r.weights);
      var intensity = Math.max.apply(null, prefs) / 100;
      s = s * (0.7 + 0.3 * intensity);
      if (pop) s = s * 0.85 + ((r.totalReactions || 25) / maxReact) * 0.15;
      var dim = demoOnly && !r.demo;
      return { r: r, s: Math.max(0, Math.min(1, s)), dim: dim };
    });
    scored.sort(function (a, b) { return (a.dim - b.dim) || (b.s - a.s); });
    var h = 0;
    var rowH = (rankEl.firstElementChild && rankEl.firstElementChild.offsetHeight + 8) || 62;
    rankEl.style.height = (rowH * scored.length - 8) + 'px';
    scored.forEach(function (x, i) {
      var li = rankItems[x.r.id];
      li.style.position = 'absolute'; li.style.left = '0'; li.style.right = '0'; li.style.top = '0';
      li.style.transform = 'translateY(' + (i * rowH) + 'px)';
      li.classList.toggle('is-dim', x.dim);
      li.querySelector('.rank__n').textContent = fa(i + 1);
      li.querySelector('.rank__score').textContent = fa(Math.round(x.s * 100)) + '٪';
      li.querySelector('.rank__bar i').style.width = Math.round(x.s * 100) + '%';
      li.style.borderColor = i === 0 && !x.dim ? 'var(--accent)' : 'transparent';
      h++;
    });
    var top = scored.filter(function (x) { return !x.dim; })[0] || scored[0];
    $('#pickName').textContent = top.r.path;
    $('#pickWhy').textContent = top.r.tagline + ' — ' + fa(Math.round(top.s * 100)) + '٪ هم‌خوانی با پروفایلت.';
    $('#pickLink').href = top.r.url;
    $('#labMeta').textContent = 'cosine · n=' + D.repos.length + (demoOnly ? ' · demo' : '') + (pop ? ' · pop' : '');

    // persona
    var mi = 0; for (var i = 1; i < 4; i++) if (prefs[i] > prefs[mi]) mi = i;
    var spread = Math.max.apply(null, prefs) - Math.min.apply(null, prefs);
    if (spread < 15 && Math.max.apply(null, prefs) > 20) {
      $('#persona').textContent = 'همه‌فن‌حریف';
      $('#personaSub').textContent = 'از هر دسته یه چیزی برات جذابه؛ کانال دقیقاً برای توئه.';
    } else if (Math.max.apply(null, prefs) < 10) {
      $('#persona').textContent = 'هنوز معلوم نیست';
      $('#personaSub').textContent = 'اسلایدرها رو بالا ببر تا ببینیم چی دوست داری.';
    } else {
      $('#persona').textContent = PERSONAS[mi].name;
      $('#personaSub').textContent = PERSONAS[mi].sub;
    }
    drawRadar();
    var sum = prefs.reduce(function (a, b) { return a + b; }, 0);
    if (Math.abs(sum - lastTickVal) > 18) { RFX.play('tick'); lastTickVal = sum; }
  }
  function drawRadar() {
    var svg = $('#radar'), cx = 120, cy = 120, R = 82, n = AXES.length, out = '';
    var pt = function (i, r) { var a = -Math.PI / 2 + i * 2 * Math.PI / n; return [cx + Math.cos(a) * r, cy + Math.sin(a) * r]; };
    [0.25, 0.5, 0.75, 1].forEach(function (k) {
      var p = []; for (var i = 0; i < n; i++) p.push(pt(i, R * k).join(','));
      out += '<polygon class="grid" points="' + p.join(' ') + '"/>';
    });
    for (var i = 0; i < n; i++) {
      var e = pt(i, R); out += '<line class="axis" x1="' + cx + '" y1="' + cy + '" x2="' + e[0] + '" y2="' + e[1] + '"/>';
      var l = pt(i, R + 22);
      out += '<text x="' + l[0] + '" y="' + (l[1] + 3) + '" text-anchor="middle">' + AXES[i].label.split(' ')[0] + '</text>';
    }
    var sp = []; for (var j = 0; j < n; j++) sp.push(pt(j, Math.max(4, R * prefs[j] / 100)).join(','));
    out += '<polygon class="shape" points="' + sp.join(' ') + '"/>';
    for (var k = 0; k < n; k++) { var d = pt(k, Math.max(4, R * prefs[k] / 100)); out += '<circle class="dot" cx="' + d[0] + '" cy="' + d[1] + '" r="4"/>'; }
    svg.innerHTML = out;
  }

  /* ======================================================
     11. Bento — process tabs, spark, donut, reactions
     ====================================================== */
  var tabs = $$('.tab'), steps = $$('.step'), stepBar = $('#stepBar'), stepIdx = 0, stepT0 = performance.now(), STEP_MS = 5200, stepPaused = false;
  function setStep(i) {
    stepIdx = i; stepT0 = performance.now();
    tabs.forEach(function (t, k) { t.classList.toggle('is-on', k === i); t.setAttribute('aria-selected', String(k === i)); });
    steps.forEach(function (s, k) { s.classList.toggle('is-on', k === i); });
  }
  tabs.forEach(function (t, i) { t.addEventListener('click', function () { setStep(i); RFX.play('pop'); }); });
  var proc = $('.card--process');
  proc.addEventListener('mouseenter', function () { stepPaused = true; });
  proc.addEventListener('mouseleave', function () { stepPaused = false; stepT0 = performance.now() - parseFloat(stepBar.style.width || 0) / 100 * STEP_MS; });
  (function loop(now) {
    if (!stepPaused) {
      var k = (now - stepT0) / STEP_MS;
      if (k >= 1) { setStep((stepIdx + 1) % steps.length); k = 0; }
      stepBar.style.width = (k * 100).toFixed(1) + '%';
    }
    requestAnimationFrame(loop);
  })(performance.now());

  function drawSpark() {
    // growth-shaped illustrative curve ending at the current count
    var p = $('#sparkPath'); if (!p) return;
    var pts = [], n = 24;
    for (var i = 0; i <= n; i++) {
      var x = i / n * 160;
      var y = 36 - Math.pow(i / n, 1.7) * 30 - Math.sin(i * 1.3) * 1.6;
      pts.push((i ? 'L' : 'M') + x.toFixed(1) + ' ' + y.toFixed(1));
    }
    p.setAttribute('d', pts.join(' '));
    var len = 400; p.style.strokeDasharray = len; p.style.strokeDashoffset = len;
    requestAnimationFrame(function () { p.style.transition = 'stroke-dashoffset 2s ease'; p.style.strokeDashoffset = 0; });
  }

  (function donut() {
    var svg = $('#donut'), legend = $('#legend'), R = 44, C = 2 * Math.PI * R, acc = 0, out = '', lg = '';
    var cats = Object.keys(D.categories);
    var total = D.repos.length;
    out += '<circle cx="60" cy="60" r="' + R + '" style="stroke:var(--surface-2)"/>';
    cats.forEach(function (k) {
      var n = D.repos.filter(function (r) { return r.cat === k; }).length; if (!n) return;
      var frac = n / total, len = frac * C;
      out += '<circle data-cat="' + k + '" cx="60" cy="60" r="' + R + '" stroke="' + D.categories[k].color + '" stroke-dasharray="' + (len - 2).toFixed(2) + ' ' + (C - len + 2).toFixed(2) + '" stroke-dashoffset="' + (-acc).toFixed(2) + '"><title>' + D.categories[k].label + '</title></circle>';
      acc += len;
      lg += '<li><i style="background:' + D.categories[k].color + '"></i>' + esc(D.categories[k].label) + '<b class="num">' + fa(Math.round(frac * 100)) + '٪</b></li>';
    });
    svg.innerHTML = out; legend.innerHTML = lg;
    $$('circle[data-cat]', svg).forEach(function (c) {
      c.addEventListener('click', function () {
        var cat = c.getAttribute('data-cat');
        var chip = chipsEl.querySelector('[data-cat="' + cat + '"]'); if (chip) chip.click();
        document.getElementById('repos').scrollIntoView({ behavior: 'smooth' });
      });
    });
  })();

  var myReacts = store.get('reacts', {});
  $$('.react').forEach(function (b) {
    var k = b.getAttribute('data-r'), num = b.querySelector('b'), base = +num.textContent;
    function paint() { var on = !!myReacts[k]; b.classList.toggle('is-on', on); num.textContent = fa(base + (on ? 1 : 0)); }
    paint();
    b.addEventListener('click', function () {
      myReacts[k] = !myReacts[k]; store.set('reacts', myReacts); paint();
      b.classList.remove('bump'); void b.offsetWidth; b.classList.add('bump');
      RFX.play('pop');
    });
  });

  /* ======================================================
     12. Card generator (canvas, 2x DPI)
     ====================================================== */
  var STACK = ['JavaScript', 'TypeScript', 'Python', 'Go', 'Rust', 'React', 'Node', 'Docker', 'Cloudflare', 'LLM', 'Linux', 'Kotlin'];
  var cardState = store.get('card', { name: '', user: '', role: 0, stack: ['TypeScript', 'Cloudflare'], repo: 'twp-cf', skin: 'carbon', serial: Math.floor(1000 + Math.random() * 14000) });
  var SKINS = {
    carbon: { bg: '#0E0F12', surf: '#17191E', ink: '#F4F1EA', ink2: '#9E9A90', acc: '#D4A359', acc2: '#E05A47' },
    ember:  { bg: '#17191E', surf: '#1F2228', ink: '#F4F1EA', ink2: '#9E9A90', acc: '#E05A47', acc2: '#D4A359' },
    paper:  { bg: '#FAF6F0', surf: '#EFE8DC', ink: '#161513', ink2: '#5C574F', acc: '#2D6A4F', acc2: '#C85A32' }
  };
  var fName = $('#fName'), fUser = $('#fUser'), fRole = $('#fRole'), fRepo = $('#fRepo'), stackEl = $('#stack');
  D.repos.forEach(function (r) { var o = document.createElement('option'); o.value = r.id; o.textContent = r.name; fRepo.appendChild(o); });
  STACK.forEach(function (s) {
    var b = document.createElement('button'); b.type = 'button'; b.textContent = s;
    b.setAttribute('aria-pressed', 'false');
    b.addEventListener('click', function () {
      var i = cardState.stack.indexOf(s);
      if (i >= 0) cardState.stack.splice(i, 1);
      else { if (cardState.stack.length >= 4) { toast('حداکثر ۴ مورد'); RFX.play('deny'); return; } cardState.stack.push(s); }
      syncStack(); saveCard(); drawCard(); RFX.play('pop');
    });
    stackEl.appendChild(b);
  });
  function syncStack() { $$('button', stackEl).forEach(function (b) { var on = cardState.stack.indexOf(b.textContent) >= 0; b.classList.toggle('is-on', on); b.setAttribute('aria-pressed', String(on)); }); }
  fName.value = cardState.name; fUser.value = cardState.user; fRole.selectedIndex = cardState.role; fRepo.value = cardState.repo;
  syncStack();
  $$('.sw').forEach(function (b) {
    b.classList.toggle('is-on', b.getAttribute('data-skin') === cardState.skin);
    b.addEventListener('click', function () {
      cardState.skin = b.getAttribute('data-skin');
      $$('.sw').forEach(function (x) { x.classList.toggle('is-on', x === b); });
      saveCard(); drawCard(); RFX.play('toggle');
    });
  });
  [fName, fUser].forEach(function (el) { el.addEventListener('input', function () { cardState.name = fName.value; cardState.user = fUser.value.replace(/[^A-Za-z0-9-_.]/g, ''); if (fUser.value !== cardState.user) fUser.value = cardState.user; saveCard(); drawCard(); }); });
  fRole.addEventListener('change', function () { cardState.role = fRole.selectedIndex; saveCard(); drawCard(); });
  fRepo.addEventListener('change', function () { cardState.repo = fRepo.value; saveCard(); drawCard(); });
  $('#shuffleBtn').addEventListener('click', function () { cardState.serial = Math.floor(1000 + Math.random() * 14000); saveCard(); drawCard(); RFX.play('whoosh'); });
  function saveCard() { store.set('card', cardState); }

  var cv = $('#cardCanvas'), W = 1200, H = 675, SCALE = 2;
  cv.width = W * SCALE; cv.height = H * SCALE;
  var cx = cv.getContext('2d');

  function rr(c, x, y, w, h, r) { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }
  function hashStr(s) { var h = 2166136261; for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
  function rng(seed) { return function () { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; }; }

  function drawCard() {
    if (!cx) return;
    var S = SKINS[cardState.skin] || SKINS.carbon;
    var name = cardState.name.trim() || 'توسعه‌دهنده‌ی ناشناس';
    var user = cardState.user.trim() || 'username';
    var role = fRole.options[cardState.role] ? fRole.options[cardState.role].text : '';
    var repo = D.repos.filter(function (r) { return r.id === cardState.repo; })[0] || D.repos[0];
    var c = cx;
    c.setTransform(SCALE, 0, 0, SCALE, 0, 0);
    c.clearRect(0, 0, W, H);

    // background
    c.fillStyle = S.bg; rr(c, 0, 0, W, H, 36); c.fill();
    c.save(); rr(c, 0, 0, W, H, 36); c.clip();

    // generative contribution grid (seeded by username) on the left side
    var rnd = rng(hashStr(user + cardState.serial));
    var cell = 22, gap = 6, cols = 16, rows = 7, gx = 70, gy = H - 70 - rows * (cell + gap);
    for (var i = 0; i < cols; i++) for (var j = 0; j < rows; j++) {
      var v = rnd();
      c.globalAlpha = v < 0.35 ? 0.08 : v < 0.6 ? 0.25 : v < 0.85 ? 0.55 : 0.95;
      c.fillStyle = v > 0.93 ? S.acc2 : S.acc;
      rr(c, gx + i * (cell + gap), gy + j * (cell + gap), cell, cell, 5); c.fill();
    }
    c.globalAlpha = 1;

    // orbit ornament top-left
    c.strokeStyle = S.ink2; c.globalAlpha = 0.25; c.lineWidth = 1.5;
    [70, 120, 170].forEach(function (r) { c.beginPath(); c.arc(170, 150, r, 0, Math.PI * 2); c.stroke(); });
    c.globalAlpha = 1;
    c.fillStyle = S.acc; c.beginPath(); c.arc(170, 150, 34, 0, Math.PI * 2); c.fill();
    c.fillStyle = S.acc2; c.beginPath(); c.arc(170 + Math.cos(-0.6) * 120, 150 + Math.sin(-0.6) * 120, 11, 0, Math.PI * 2); c.fill();
    c.fillStyle = S.ink; c.beginPath(); c.arc(170 + Math.cos(2.2) * 170, 150 + Math.sin(2.2) * 170, 8, 0, Math.PI * 2); c.fill();

    // right panel
    c.fillStyle = S.surf; rr(c, 560, 40, 600, H - 80, 28); c.fill();
    c.restore();

    c.direction = 'rtl'; c.textAlign = 'right'; c.textBaseline = 'alphabetic';
    var R = 1120;
    c.fillStyle = S.acc; c.font = '700 22px Vazirmatn';
    c.fillText('کارت عضویت ریپوفا', R, 100);
    c.fillStyle = S.ink2; c.font = '500 18px "JetBrains Mono"'; c.direction = 'ltr'; c.textAlign = 'left';
    c.fillText('No. ' + String(cardState.serial).padStart(5, '0'), 600, 100);
    c.direction = 'rtl'; c.textAlign = 'right';

    // name (auto-fit)
    var fs = 76; c.font = '400 ' + fs + 'px Lalezar';
    while (c.measureText(name).width > 520 && fs > 36) { fs -= 4; c.font = '400 ' + fs + 'px Lalezar'; }
    c.fillStyle = S.ink; c.fillText(name, R, 200);
    c.fillStyle = S.ink2; c.font = '500 26px Vazirmatn'; c.fillText(role, R, 248);
    c.direction = 'ltr'; c.textAlign = 'right';
    c.fillStyle = S.acc; c.font = '600 24px "JetBrains Mono"'; c.fillText('github.com/' + user, R, 292);

    // stack pills
    var px = R; c.font = '600 19px "JetBrains Mono"';
    (cardState.stack.length ? cardState.stack : ['open-source']).forEach(function (s) {
      var w = c.measureText(s).width + 32;
      c.fillStyle = S.bg; rr(c, px - w, 330, w, 40, 20); c.fill();
      c.strokeStyle = S.ink2; c.globalAlpha = 0.35; c.lineWidth = 1.2; c.stroke(); c.globalAlpha = 1;
      c.fillStyle = S.ink; c.textAlign = 'center'; c.fillText(s, px - w / 2, 357); c.textAlign = 'right';
      px -= w + 10;
    });

    // favourite repo
    c.direction = 'rtl'; c.textAlign = 'right';
    c.fillStyle = S.ink2; c.font = '500 18px Vazirmatn'; c.fillText('ریپوی محبوب از کانال', R, 430);
    c.direction = 'ltr'; c.fillStyle = S.ink; c.font = '700 30px "Bricolage Grotesque"';
    var rn = repo.path; while (c.measureText(rn).width > 520) rn = rn.slice(0, -2);
    if (rn !== repo.path) rn += '…';
    c.fillText(rn, R, 472);
    c.direction = 'rtl'; c.fillStyle = S.ink2; c.font = '400 19px Vazirmatn';
    var tg = repo.tagline; while (c.measureText(tg).width > 520) tg = tg.slice(0, -2);
    c.fillText(tg, R, 506);

    // divider + footer
    c.strokeStyle = S.ink2; c.globalAlpha = 0.25; c.setLineDash([6, 8]); c.beginPath(); c.moveTo(600, 548); c.lineTo(R, 548); c.stroke(); c.setLineDash([]); c.globalAlpha = 1;
    c.fillStyle = S.ink; c.font = '400 34px Lalezar'; c.fillText('ریپوفا', R, 604);
    c.fillStyle = S.ink2; c.font = '500 16px "JetBrains Mono"'; c.direction = 'ltr'; c.textAlign = 'left';
    c.fillText('t.me/RepoFA  ·  Persian GitHub', 600, 600);

    // brand mark on left
    c.save(); c.translate(70, 300);
    c.fillStyle = S.surf; rr(c, 0, 0, 92, 92, 24); c.fill();
    c.strokeStyle = S.acc; c.lineWidth = 9; c.lineCap = 'round'; c.lineJoin = 'round';
    c.beginPath(); c.moveTo(29, 70); c.lineTo(29, 26); c.lineTo(51, 26); c.arc(51, 40, 14, -Math.PI / 2, Math.PI / 2); c.lineTo(39, 54); c.moveTo(51, 54); c.lineTo(65, 70); c.stroke();
    c.fillStyle = S.acc2; c.beginPath(); c.arc(70, 26, 6, 0, Math.PI * 2); c.fill();
    c.restore();
    c.direction = 'ltr'; c.textAlign = 'left'; c.fillStyle = S.ink2; c.font = '500 15px "JetBrains Mono"';
    c.fillText('CONTRIBUTIONS · SEED ' + (hashStr(user) % 9999), 70, gy - 16);
  }

  $('#dlBtn').addEventListener('click', function () {
    drawCard();
    var a = document.createElement('a');
    var fn = 'repofa-card-' + (cardState.user || 'dev') + '.png';
    try {
      cv.toBlob(function (b) {
        if (!b) { a.href = cv.toDataURL('image/png'); }
        else { a.href = URL.createObjectURL(b); }
        a.download = fn; document.body.appendChild(a); a.click(); a.remove();
        setTimeout(function () { if (b) URL.revokeObjectURL(a.href); }, 2000);
        toast('کارتت دانلود شد 🎉'); RFX.play('success');
      }, 'image/png');
    } catch (e) { toast('دانلود ممکن نشد'); }
  });

  /* ======================================================
     13. Poll
     ====================================================== */
  var POLL = [
    { id: 'ai', label: 'ایجنت و ابزارهای هوش مصنوعی', base: 412 },
    { id: 'cf', label: 'پروژه‌های سرورلس و Cloudflare', base: 356 },
    { id: 'sci', label: 'شبیه‌سازها و پروژه‌های آموزشی', base: 198 },
    { id: 'tool', label: 'ابزارهای دسکتاپ و بهره‌وری', base: 274 }
  ];
  var myVote = store.get('vote', null);
  var pollEl = $('#poll');
  POLL.forEach(function (o) {
    var b = document.createElement('button');
    b.className = 'opt'; b.type = 'button'; b.setAttribute('data-id', o.id);
    b.innerHTML = '<i class="opt__fill"></i><span>' + esc(o.label) + '</span><b class="num"></b>';
    b.addEventListener('click', function () {
      myVote = myVote === o.id ? null : o.id; store.set('vote', myVote); paintPoll(true);
      RFX.play(myVote ? 'success' : 'toggle');
    });
    pollEl.appendChild(b);
  });
  function paintPoll(voted) {
    var total = POLL.reduce(function (s, o) { return s + o.base + (myVote === o.id ? 1 : 0); }, 0);
    POLL.forEach(function (o) {
      var b = pollEl.querySelector('[data-id="' + o.id + '"]');
      var v = o.base + (myVote === o.id ? 1 : 0), pc = v / total * 100;
      b.querySelector('.opt__fill').style.width = (myVote || voted ? pc : 0) + '%';
      b.querySelector('b').textContent = myVote ? fa(Math.round(pc)) + '٪' : '';
      b.classList.toggle('is-mine', myVote === o.id);
    });
    $('#pollMeta').textContent = myVote ? fa(total) + ' رأی · رأی تو ثبت شد (دوباره بزنی پس گرفته میشه)' : 'برای دیدن نتیجه رأی بده.';
  }
  paintPoll(false);

  /* ======================================================
     14. Leaderboard (real reactions + your in-scene stars)
     ====================================================== */
  var sceneStars = {};
  function paintBoard() {
    var list = D.repos.map(function (r) { return { r: r, v: (r.totalReactions || 0) + (sceneStars[r.id] || 0) }; })
      .sort(function (a, b) { return b.v - a.v; }).slice(0, 5);
    $('#leaderboard').innerHTML = list.map(function (x) {
      return '<li><span class="lb__name">' + esc(x.r.name) + '</span><span class="lb__val">' + fa(x.v) + (sceneStars[x.r.id] ? ' <small style="color:var(--accent)">+' + fa(sceneStars[x.r.id]) + '★</small>' : '') + '</span></li>';
    }).join('');
  }
  document.addEventListener('scene:star', function (e) { var id = e.detail.repo.id; sceneStars[id] = (sceneStars[id] || 0) + 1; paintBoard(); });
  paintBoard();

  /* ======================================================
     15. Init
     ====================================================== */
  $('#yr').textContent = fa(new Date().getFullYear());
  renderRepos();
  applyTheme(store.get('theme', 'carbon'), true);
  updateLab();
  drawSpark();
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(function () { drawCard(); updateLab(); if (window.RepoScene) window.RepoScene.setTheme(document.documentElement.getAttribute('data-theme')); });
  window.addEventListener('resize', function () { clearTimeout(window.__rz); window.__rz = setTimeout(updateLab, 150); });
  document.addEventListener('keydown', function (e) {
    if (e.target.matches('input, select, textarea')) return;
    if (e.key === '/') { e.preventDefault(); qEl.focus(); qEl.scrollIntoView({ behavior: 'smooth', block: 'center' }); }
  });
})();
